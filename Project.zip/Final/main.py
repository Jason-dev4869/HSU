"""
Advanced Maze Solver — GUI pathfinding demo (BFS, DFS, Greedy, A*).

HOW TO RUN
----------
1. Install Python 3.10+ (Tkinter is bundled on Windows).
2. From this folder, run:  python main.py
3. Set maze parameters in the left panel, then click **Generate Maze**.
4. Run one algorithm (button above each maze) or **Run + Animate All** to compare all four.

WHAT EACH BUTTON DOES
---------------------
- **Generate Maze** — Builds a new grid from size, start, goal, and obstacle count.
- **Run BFS / DFS / Greedy / A*** (above each panel) — Solves and animates that algorithm only.
- **Run + Animate All** — Runs all four side-by-side with synchronized animation.

COLOR LEGEND (each maze panel)
------------------------------
- Green = start   Red = goal   Dark gray = obstacle
- Light blue = visited cells   Yellow = solution path

SCROLLING
---------
- Use window scrollbars or the mouse wheel to see metrics and history below.
- Search trees and history text have their own scrollbars when content is long.

CODE LAYOUT
-----------
- MazeModel      — grid, obstacles, transition function (problem definition)
- MazeSolver     — search algorithms (no GUI)
- MazeApp        — Tkinter interface, drawing, animation
"""

# =============================================================================
# Entry point
# =============================================================================

import random
import tkinter as tk
from GUI.app import MazeApp

def main() -> None:
    """Application entry point."""
    random.seed()
    root = tk.Tk()
    app = MazeApp(root)
    root.mainloop()


if __name__ == "__main__":
    # Run this file directly:  python main.py
    main()