from Core.types import Position
from Core.search_result import SearchResult
from Core.model import MazeModel
from Utils.utils import reconstruct_path

import time, math
from collections import deque
from heapq import heappop, heappush


# =============================================================================
# MazeSolver — graph search (no GUI; returns SearchResult for the app)
# =============================================================================
class MazeSolver:
    @staticmethod
    def bfs(model: MazeModel) -> SearchResult:
        """Breadth-first search: FIFO frontier, shortest path when step cost is uniform."""
        start_t = time.perf_counter()
        q = deque([model.start])
        parent: dict[Position, Position | None] = {model.start: None}
        visited = {model.start}
        visited_order: list[Position] = []
        edges: list[tuple[Position, Position]] = []
        max_frontier = 1

        while q:
            max_frontier = max(max_frontier, len(q))
            cur = q.popleft()
            visited_order.append(cur)
            if cur == model.goal:
                break
            for _, nxt in model.neighbors(cur):
                if nxt in visited:
                    continue
                visited.add(nxt)
                parent[nxt] = cur
                edges.append((cur, nxt))
                q.append(nxt)

        path = reconstruct_path(parent, model.goal)
        elapsed = (time.perf_counter() - start_t) * 1000
        return SearchResult(
            algorithm="BFS",
            found=bool(path),
            path=path,
            visited_order=visited_order,
            edges=edges,
            nodes_expanded=len(visited_order),
            max_frontier=max_frontier,
            elapsed_ms=elapsed,
            completeness="Complete",
            optimality="Optimal (uniform step costs)",
            time_complexity="O(V + E)",
            space_complexity="O(V)",
        )

    @staticmethod
    def dfs(model: MazeModel) -> SearchResult:
        """Depth-first search: LIFO stack; explores one branch deeply before backtracking."""
        start_t = time.perf_counter()
        stack = [model.start]
        parent: dict[Position, Position | None] = {model.start: None}
        visited = {model.start}
        visited_order: list[Position] = []
        edges: list[tuple[Position, Position]] = []
        max_frontier = 1

        while stack:
            max_frontier = max(max_frontier, len(stack))
            cur = stack.pop()
            visited_order.append(cur)
            if cur == model.goal:
                break
            # Reversed neighbor order makes expansion order deterministic for the demo.
            for _, nxt in reversed(model.neighbors(cur)):
                if nxt in visited:
                    continue
                visited.add(nxt)
                parent[nxt] = cur
                edges.append((cur, nxt))
                stack.append(nxt)

        path = reconstruct_path(parent, model.goal)
        elapsed = (time.perf_counter() - start_t) * 1000
        return SearchResult(
            algorithm="DFS",
            found=bool(path),
            path=path,
            visited_order=visited_order,
            edges=edges,
            nodes_expanded=len(visited_order),
            max_frontier=max_frontier,
            elapsed_ms=elapsed,
            completeness="Complete (finite graph + visited set)",
            optimality="Not optimal",
            time_complexity="O(V + E)",
            space_complexity="O(V)",
        )

    @staticmethod
    def manhattan(a: Position, b: Position) -> float:
        """L1 distance — admissible heuristic for grid moves without diagonals."""
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    @staticmethod
    def euclidean(a: Position, b: Position) -> float:
        """Straight-line distance — also admissible without diagonal moves."""
        return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)

    @staticmethod
    def greedy_best_first(model: MazeModel, heuristic_name: str) -> SearchResult:
        """Greedy best-first: expand the cell with smallest h(n) to the goal."""
        heuristic = MazeSolver.manhattan if heuristic_name == "Manhattan" else MazeSolver.euclidean
        start_t = time.perf_counter()
        pq: list[tuple[float, Position]] = []
        heappush(pq, (heuristic(model.start, model.goal), model.start))
        parent: dict[Position, Position | None] = {model.start: None}
        visited = {model.start}
        visited_order: list[Position] = []
        edges: list[tuple[Position, Position]] = []
        max_frontier = 1

        while pq:
            max_frontier = max(max_frontier, len(pq))
            _, cur = heappop(pq)
            visited_order.append(cur)
            if cur == model.goal:
                break
            for _, nxt in model.neighbors(cur):
                if nxt in visited:
                    continue
                visited.add(nxt)
                parent[nxt] = cur
                edges.append((cur, nxt))
                heappush(pq, (heuristic(nxt, model.goal), nxt))

        path = reconstruct_path(parent, model.goal)
        elapsed = (time.perf_counter() - start_t) * 1000
        return SearchResult(
            algorithm=f"Greedy Best-First ({heuristic_name})",
            found=bool(path),
            path=path,
            visited_order=visited_order,
            edges=edges,
            nodes_expanded=len(visited_order),
            max_frontier=max_frontier,
            elapsed_ms=elapsed,
            completeness="Complete (finite graph + visited set)",
            optimality="Not optimal",
            time_complexity="O(E log V)",
            space_complexity="O(V)",
        )

    @staticmethod
    def a_star(model: MazeModel, heuristic_name: str) -> SearchResult:
        """A*: expand lowest f(n) = g(n) + h(n); optimal with admissible heuristic."""
        heuristic = MazeSolver.manhattan if heuristic_name == "Manhattan" else MazeSolver.euclidean
        start_t = time.perf_counter()
        pq: list[tuple[float, Position]] = []
        g_cost: dict[Position, float] = {model.start: 0.0}
        parent: dict[Position, Position | None] = {model.start: None}
        heappush(pq, (heuristic(model.start, model.goal), model.start))
        closed: set[Position] = set()
        visited_order: list[Position] = []
        edges: list[tuple[Position, Position]] = []
        max_frontier = 1

        while pq:
            max_frontier = max(max_frontier, len(pq))
            _, cur = heappop(pq)
            if cur in closed:
                continue
            closed.add(cur)
            visited_order.append(cur)
            if cur == model.goal:
                break

            for _, nxt in model.neighbors(cur):
                tentative = g_cost[cur] + 1.0
                if tentative < g_cost.get(nxt, float("inf")):
                    g_cost[nxt] = tentative
                    parent[nxt] = cur
                    edges.append((cur, nxt))
                    f = tentative + heuristic(nxt, model.goal)
                    heappush(pq, (f, nxt))

        path = reconstruct_path(parent, model.goal)
        elapsed = (time.perf_counter() - start_t) * 1000
        return SearchResult(
            algorithm=f"A* ({heuristic_name})",
            found=bool(path),
            path=path,
            visited_order=visited_order,
            edges=edges,
            nodes_expanded=len(visited_order),
            max_frontier=max_frontier,
            elapsed_ms=elapsed,
            completeness="Complete (finite graph + positive costs)",
            optimality="Optimal (admissible/consistent heuristic)",
            time_complexity="O(E log V)",
            space_complexity="O(V)",
        )