import random
import numpy as np

from Core.types import Position

# =============================================================================
# MazeGenerator — maze generation algorithms (returns frames for the animation)
# =============================================================================
class MazeGenerator:
    @staticmethod
    def dfs_maze_generation(maze: np.ndarray, start: Position) -> list[np.ndarray]:
        """Depth-first search (Randomized): Uses a LIFO stack to carve out a maze."""
        rows, cols = maze.shape
        stack = [start]
        frames = []
        visited = set()
        visited.add(start)

        while stack:
            current = stack.pop()
            x, y = current
            maze[x, y] = -1  # Mark the current cell as part of the path
            frames.append(maze.copy())

            directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
            random.shuffle(directions)

            for dx, dy in directions:
                nx, ny = x + dx * 2, y + dy * 2
                if 0 <= nx < rows and 0 <= ny < cols and (nx, ny) not in visited:
                    visited.add((nx, ny))
                    stack.append((nx, ny))
                    maze[x + dx, y + dy] = -1

        return frames
    
    @staticmethod
    def prim_maze_generation(maze: np.ndarray, start: Position) -> list[np.ndarray]:
        """Prim's Algorithm (Randomized): Grows a maze from a starting point using a wall list."""
        rows, cols = maze.shape
        frames = []

        maze[start] = -1
        frames.append(maze.copy())
        visited = {start}
        walls: list[tuple[int, int, int, int]] = []

        def add_walls_of_cell(cx: int, cy: int) -> None:
            for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                wx, wy = cx + dx, cy + dy
                nx, ny = cx + dx * 2, cy + dy * 2

                if 0 <= nx < rows and 0 <= ny < cols and (nx, ny) not in visited:
                    walls.append((wx, wy, nx, ny))

        add_walls_of_cell(start[0], start[1])

        while walls:
            wall_data = random.choice(walls)
            walls.remove(wall_data)
            wx, wy, nx, ny = wall_data

            if (nx, ny) not in visited:
                maze[wx, wy] = -1
                maze[nx, ny] = -1
                frames.append(maze.copy())
                visited.add((nx, ny))
                add_walls_of_cell(nx, ny)

        return frames

    @staticmethod
    def hunt_and_kill_maze_generation(maze: np.ndarray, start: Position) -> list[np.ndarray]:
        """Hunt and Kill Algorithm: Errant walks until stuck, then hunts for a new start."""
        rows, cols = maze.shape
        frames = []
        visited = set()
        current = start

        while True:
            maze[current] = -1
            visited.add(current)
            frames.append(maze.copy())

            directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
            random.shuffle(directions)

            found_unvisited_neighbor = False
            for dx, dy in directions:
                nx, ny = current[0] + dx * 2, current[1] + dy * 2
                if 0 <= nx < rows and 0 <= ny < cols and (nx, ny) not in visited:
                    visited.add((nx, ny))
                    maze[current[0] + dx, current[1] + dy] = -1
                    current = (nx, ny)
                    found_unvisited_neighbor = True
                    break

            if not found_unvisited_neighbor:
                found_next_start = False
                for i in range(1, rows, 2):
                    for j in range(1, cols, 2):
                        if (i, j) not in visited:
                            for dx, dy in directions:
                                adj_x, adj_y = i + dx * 2, j + dy * 2
                                if (adj_x, adj_y) in visited:
                                    maze[i + dx, j + dy] = -1
                                    current = (i, j)
                                    found_next_start = True
                                    break
                            if found_next_start:
                                break
                    if found_next_start:
                        break

                if not found_next_start:
                    break

        return frames
    
    @staticmethod
    def sidewinder_maze_generation(maze: np.ndarray, start: Position) -> list[np.ndarray]:
        """Sidewinder Algorithm: Processes maze row by row, carving east or linking north."""
        rows, cols = maze.shape
        frames = []

        for i in range(1, rows, 2):
            current_run = []

            for j in range(1, cols, 2):
                current = (i, j)
                maze[current] = -1
                current_run.append(current)
                frames.append(maze.copy())

                can_go_right = (j + 2) < cols
                can_go_up = (i - 2) > 0

                if can_go_right and (not can_go_up or random.choice([True, False])):
                    maze[i, j + 1] = -1
                    frames.append(maze.copy())
                else:
                    if can_go_up:
                        member_i, member_j = random.choice(current_run)
                        maze[member_i - 1, member_j] = -1
                        frames.append(maze.copy())

                    current_run = []

        return frames