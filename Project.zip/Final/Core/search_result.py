from dataclasses import dataclass
from Core.types import Position

@dataclass
class SearchResult:
    """Everything one algorithm run returns for drawing trees, paths, and metrics."""

    algorithm: str
    found: bool
    path: list[Position]  # start → goal (empty if no solution)
    visited_order: list[Position]  # order cells were expanded/dequeued
    edges: list[tuple[Position, Position]]  # (parent, child) for the search tree
    nodes_expanded: int
    max_frontier: int  # peak queue/stack/heap size
    elapsed_ms: float
    completeness: str
    optimality: str
    time_complexity: str
    space_complexity: str