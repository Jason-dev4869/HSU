from typing import TypeAlias

# Grid cell coordinates: (row, col), both zero-based from the top-left corner.
Position: TypeAlias = tuple[int, int]