import random
from Core.types import Position

# Định nghĩa các hằng số đồng bộ với MazeEditorApp
CELL_WALL = 0
CELL_PATH = -1
CELL_START = 2
CELL_GOAL = 3

# =============================================================================
# MazeModel — problem definition (Loaded from Maze Editor grid)
# =============================================================================
class MazeModel:
    """
    Problem definition updated to support (2n+1)x(2n+1) grids from Maze Editor.
    Extracts start, goal, and obstacle set directly from the full grid array.
    """

    def __init__(self, grid_array: list[list[int]] | None = None):
        """
        Khởi tạo Model từ mảng grid của Maze Editor.
        Nếu không truyền grid_array, tạo mặc định một mê cung trống 3x3.
        """
        if grid_array is None:
            # Mê cung mặc định nhỏ nhất (n=1 -> grid 3x3) đầy đủ viền tường, start và goal
            grid_array = [
                [0, 0, 0],
                [0, 2, 0],
                [0, 3, 0]
            ]
            
        self.grid = grid_array
        self.rows = len(grid_array)
        self.cols = len(grid_array[0]) if self.rows > 0 else 0
        
        self.start: Position = (1, 1)
        self.goal: Position = (1, 1)
        self.obstacles: set[Position] = set()
        
        # Tự động phân tích mảng grid để nạp dữ liệu vào Model
        self._parse_grid_array()

    def _parse_grid_array(self) -> None:
        """Quét qua mảng 2D để tìm vị trí Start, Goal và các ô Tường (Obstacles)."""
        self.obstacles.clear()
        for r in range(self.rows):
            for c in range(self.cols):
                val = self.grid[r][c]
                if val == CELL_WALL:
                    self.obstacles.add((r, c))
                elif val == CELL_START:
                    self.start = (r, c)
                elif val == CELL_GOAL:
                    self.goal = (r, c)
                # CELL_PATH (-1) mặc định là đường đi tự do, không xử lý

    def in_bounds(self, pos: Position) -> bool:
        """True nếu (row, col) nằm trong phạm vi ma trận grid."""
        r, c = pos
        return 0 <= r < self.rows and 0 <= c < self.cols

    def is_blocked(self, pos: Position) -> bool:
        """True nếu ô đó là Tường (được lưu trong tập obstacles)."""
        return pos in self.obstacles

    def transition(self, state: Position, action: str) -> Position | None:
        """Di chuyển một bước; trả về trạng thái mới hoặc None nếu đụng tường/ra biên."""
        deltas = {
            "up": (-1, 0),
            "down": (1, 0),
            "left": (0, -1),
            "right": (0, 1),
        }
        dr, dc = deltas[action]
        nxt = (state[0] + dr, state[1] + dc)
        if not self.in_bounds(nxt) or self.is_blocked(nxt):
            return None
        return nxt

    def _transition_failure_label(self, state: Position, action: str) -> str:
        """Trả về nhãn text thông báo lý do không thể di chuyển (phục vụ GUI)."""
        deltas = {
            "up": (-1, 0),
            "down": (1, 0),
            "left": (0, -1),
            "right": (0, 1),
        }
        dr, dc = deltas[action]
        nxt = (state[0] + dr, state[1] + dc)
        if not self.in_bounds(nxt):
            return "(out of bounds)"
        if self.is_blocked(nxt):
            return "(obstacle)"
        return "(illegal)"

    def transitions_at_state(self, state: Position) -> list[tuple[Position, str, str]]:
        """Lấy tất cả 4 hành động tại trạng thái hiện tại kèm theo nhãn kết quả."""
        if self.is_blocked(state):
            return []
        rows: list[tuple[Position, str, str]] = []
        for action in ["up", "down", "left", "right"]:
            nxt = self.transition(state, action)
            label = str(nxt) if nxt is not None else self._transition_failure_label(state, action)
            rows.append((state, action, label))
        return rows

    def neighbors(self, state: Position) -> list[tuple[str, Position]]:
        """Trả về danh sách các cặp (hành động, ô_tiếp_theo) hợp lệ."""
        actions = ["up", "down", "left", "right"]
        valid: list[tuple[str, Position]] = []
        for action in actions:
            nxt = self.transition(state, action)
            if nxt is not None:
                valid.append((action, nxt))
        return valid

    def transition_table_sample(self, rows: int = 16) -> list[tuple[Position, str, str]]:
        """Trích xuất mẫu dữ liệu bảng chuyển trạng thái để hiển thị lên GUI."""
        sample: list[tuple[Position, str, str]] = []
        seen: set[tuple[Position, str]] = set()

        def add_state(state: Position) -> None:
            if self.is_blocked(state):
                return
            for st, action, label in self.transitions_at_state(state):
                key = (st, action)
                if key in seen:
                    continue
                seen.add(key)
                sample.append((st, action, label))
                if len(sample) >= rows:
                    return

        # Ưu tiên đưa các ô xung quanh Start và Goal vào bảng trước để UI sinh động
        priority: list[Position] = []
        for pos in (self.start, self.goal):
            if pos not in priority:
                priority.append(pos)
        for obs in self.obstacles:
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nb = (obs[0] + dr, obs[1] + dc)
                if self.in_bounds(nb) and not self.is_blocked(nb) and nb not in priority:
                    priority.append(nb)

        for state in priority:
            if len(sample) >= rows:
                return sample
            add_state(state)

        for r in range(self.rows):
            for c in range(self.cols):
                if len(sample) >= rows:
                    return sample
                state = (r, c)
                if state in priority or self.is_blocked(state):
                    continue
                add_state(state)
        return sample