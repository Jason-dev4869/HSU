"""
Maze Designer — Tkinter UI
===========================
- Vẽ tay mê cung n x n: wall_pen / erase / start / goal.
- Start/Goal là GIÁ TRỊ trong mảng maze (CELL_START / CELL_GOAL), không
  còn track riêng bằng tuple + cơ chế "avoid" nữa. Muốn đổi vị trí
  Start/Goal thì phải tự vẽ đè (wall_pen/start/goal) hoặc erase ô cũ.
- Sinh mê cung tự động (DFS/Prim/Hunt&Kill/Sidewinder) có animation.
- Save/Load: validate đúng 1 Start và đúng 1 Goal, nếu không sẽ popup
  cảnh báo và chặn hành động.

Chạy: python maze_editor_app.py   (cần numpy: pip install numpy)
"""

import json
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np

from Algorithm.maze_generator import MazeGenerator

CELL_WALL = 0
CELL_PATH = -1
CELL_START = 2
CELL_GOAL = 3

ALGORITHMS = {
    "DFS (Randomized)": MazeGenerator.dfs_maze_generation,
    "Prim's Algorithm": MazeGenerator.prim_maze_generation,
    "Hunt and Kill": MazeGenerator.hunt_and_kill_maze_generation,
    "Sidewinder": MazeGenerator.sidewinder_maze_generation,
}

CANVAS_MAX_PX = 600
MIN_CELL_PX = 4
MAX_N = 100


class MazeEditorApp:
    def __init__(self, root: tk.Tk, on_apply=None):
        self.root = root
        self.root.title("Maze Designer")
        self.root.resizable(False, False)

        # Lưu lại hàm callback từ app chính truyền sang
        self.on_apply_callback = on_apply 

        self.n = 10
        self.grid_dim = 2 * self.n + 1
        self.maze = np.zeros((self.grid_dim, self.grid_dim), dtype=int)
        self._gen_time = None

        self.tool = tk.StringVar(value="wall_pen")
        self.algo_name = tk.StringVar(value=next(iter(ALGORITHMS)))
        self.n_var = tk.StringVar(value=str(self.n))

        self._animating = False
        self._anim_job = None

        self._build_ui()
        self._redraw()

    # ------------------------------------------------------------- UI ----
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=12)
        outer.grid(row=0, column=0, sticky="nsew")

        left = ttk.Frame(outer)
        left.grid(row=0, column=0, sticky="n")

        ttk.Label(
            left, text="Setting maze : wall pen, erase, start, goal",
            font=("Segoe UI", 10, "bold"),
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))

        tools = [
            ("Wall Pen", "wall_pen"),
            ("Erase", "erase"),
            ("Start", "start"),
            ("Goal", "goal"),
        ]
        for i, (label, value) in enumerate(tools):
            ttk.Radiobutton(
                left, text=label, value=value, variable=self.tool
            ).grid(row=1, column=i, sticky="w", padx=(0, 10), pady=(0, 8))

        self.canvas = tk.Canvas(
            left, width=CANVAS_MAX_PX, height=CANVAS_MAX_PX, bg="white",
            highlightthickness=1, highlightbackground="#444444",
        )
        self.canvas.grid(row=2, column=0, columnspan=4)
        self.canvas.bind("<Button-1>", self._on_canvas_click)
        self.canvas.bind("<B1-Motion>", self._on_canvas_drag)

        right = ttk.Frame(outer, padding=(24, 0, 0, 0))
        right.grid(row=0, column=1, sticky="n")

        ttk.Label(right, text="Maze info", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, sticky="w", pady=(0, 6)
        )
        self.info_box = tk.Text(
            right, width=34, height=9, state="disabled",
            bg="#f4f4f4", relief="solid", borderwidth=1, font=("Consolas", 9),
        )
        self.info_box.grid(row=1, column=0, sticky="w", pady=(0, 18))

        ttk.Label(right, text="Generate maze", font=("Segoe UI", 10, "bold")).grid(
            row=2, column=0, sticky="w", pady=(0, 6)
        )

        gen_frame = ttk.Frame(right)
        gen_frame.grid(row=3, column=0, sticky="w")

        ttk.Label(gen_frame, text="n =").grid(row=0, column=0, sticky="w")
        ttk.Entry(gen_frame, textvariable=self.n_var, width=6).grid(
            row=0, column=1, padx=(4, 12)
        )
        ttk.Combobox(
            gen_frame, textvariable=self.algo_name, values=list(ALGORITHMS.keys()),
            state="readonly", width=20,
        ).grid(row=0, column=2)

        gen_btn_frame = ttk.Frame(right)
        gen_btn_frame.grid(row=4, column=0, sticky="w", pady=(10, 0))
        ttk.Button(
            gen_btn_frame, text="Generate Maze", command=self._on_generate
        ).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(
            gen_btn_frame, text="Erase Maze", command=self._on_erase_maze
        ).grid(row=0, column=1)

        btn_frame = ttk.Frame(right)
        btn_frame.grid(row=5, column=0, sticky="w", pady=(36, 0))
        
        # THÊM NÚT APPLY VÀO ĐÂY
        ttk.Button(btn_frame, text="Apply Maze", command=self._on_apply).grid(
            row=0, column=0, padx=(0, 8)
        )
        # Dịch chuyển vị trí cột (row, column) của các nút cũ sang bên phải một chút
        ttk.Button(btn_frame, text="Save Maze", command=self._on_save).grid(
            row=0, column=1, padx=(0, 8)
        )
        ttk.Button(btn_frame, text="Load Maze", command=self._on_load).grid(
            row=0, column=2, padx=(0, 8)
        )
        ttk.Button(btn_frame, text="Cancel", command=self._on_cancel).grid(
            row=0, column=3
        )

        self._update_info()

        self.info_box = tk.Text(
            right, width=34, height=11, state="disabled", # Tăng height lên 11 để có chỗ chứa cảnh báo
            bg="#f4f4f4", relief="solid", borderwidth=1, font=("Consolas", 9),
        )
        self.info_box.grid(row=1, column=0, sticky="w", pady=(0, 18))
        
        # THÊM DÒNG NÀY: Định nghĩa tag "warning" hiển thị chữ màu đỏ đậm
        self.info_box.tag_configure("warning", foreground="#c0392b", font=("Consolas", 9, "bold"))

    # --------------------------------------------------------- DRAWING ---
    def _cell_px(self) -> int:
        return max(MIN_CELL_PX, CANVAS_MAX_PX // self.grid_dim)

    def _cell_color(self, r: int, c: int) -> str:
        v = self.maze[r, c]
        if v == CELL_START:
            return "#2ecc71"   # xanh lá
        if v == CELL_GOAL:
            return "#e74c3c"   # đỏ
        if v == CELL_WALL:
            return "#222222"   # đen
        return "#ffffff"       # trắng: path

    def _redraw(self):
        px = self._cell_px()
        dim_px = px * self.grid_dim
        self.canvas.config(width=dim_px, height=dim_px)
        self.canvas.delete("all")
        for r in range(self.grid_dim):
            for c in range(self.grid_dim):
                x0, y0 = c * px, r * px
                self.canvas.create_rectangle(
                    x0, y0, x0 + px, y0 + px,
                    fill=self._cell_color(r, c), outline="#cccccc",
                )

    def _redraw_cell(self, r: int, c: int):
        px = self._cell_px()
        x0, y0 = c * px, r * px
        self.canvas.create_rectangle(
            x0, y0, x0 + px, y0 + px,
            fill=self._cell_color(r, c), outline="#cccccc",
        )

    # --------------------------------------------------------- EVENTS ----
    def _cell_from_event(self, event):
        px = self._cell_px()
        c, r = event.x // px, event.y // px
        if 0 <= r < self.grid_dim and 0 <= c < self.grid_dim:
            return r, c
        return None

    def _on_canvas_click(self, event):
        if self._animating:
            return
        cell = self._cell_from_event(event)
        if cell:
            self._apply_tool(cell)

    def _on_canvas_drag(self, event):
        # Kéo chuột chỉ áp dụng cho wall_pen/erase — start/goal chỉ đặt
        # bằng click rời rạc để tránh quẹt marker tràn lan.
        if self._animating or self.tool.get() not in ("wall_pen", "erase"):
            return
        cell = self._cell_from_event(event)
        if cell:
            self._apply_tool(cell)
    
    def _on_apply(self):
        """Kiểm tra tính hợp lệ của mê cung rồi đẩy thẳng dữ liệu về App chính."""
        if self._animating:
            return
            
        # Vẫn cần validate bắt buộc phải có đúng 1 Start và 1 Goal
        if not self._validate_markers(self.maze, "áp dụng mê cung này"):
            return

        if self.on_apply_callback:
            # Chuyển đổi numpy array thành list thuần để đồng bộ dữ liệu JSON/List
            maze_data = self.maze.tolist()
            # Gọi hàm callback truyền dữ liệu ngược về app chính
            self.on_apply_callback(maze_data)
            # Tự động đóng cửa sổ Editor sau khi đã apply thành công
            self.root.destroy()
        else:
            messagebox.showinfo("Thông báo", "Editor đang chạy độc lập, không có App chính nhận dữ liệu.")

    def _apply_tool(self, cell):
        """Không còn avoid_position: vẽ tool nào thì GHI ĐÈ giá trị ô đó,
        kể cả khi ô đó đang là Start/Goal. Muốn đổi vị trí Start/Goal,
        người dùng tự đè (vẽ marker mới ở chỗ khác) hoặc erase ô cũ."""
        r, c = cell
        tool = self.tool.get()
        if tool == "wall_pen":
            self.maze[r, c] = CELL_WALL
        elif tool == "erase":
            self.maze[r, c] = CELL_PATH
        elif tool == "start":
            self.maze[r, c] = CELL_START
        elif tool == "goal":
            self.maze[r, c] = CELL_GOAL
        self._redraw_cell(r, c)
        self._update_info()

    # ------------------------------------------------------- VALIDATION --
    def _count_markers(self, maze: np.ndarray):
        start_count = int(np.sum(maze == CELL_START))
        goal_count = int(np.sum(maze == CELL_GOAL))
        return start_count, goal_count

    def _marker_position(self, maze: np.ndarray, value: int):
        positions = np.argwhere(maze == value)
        if len(positions) == 1:
            return tuple(int(x) for x in positions[0])
        return None

    def _validate_markers(self, maze: np.ndarray, action_label: str) -> bool:
        """Kiểm tra maze có ĐÚNG 1 Start và ĐÚNG 1 Goal. 
        Nếu sai, hiển thị lỗi trực tiếp lên info_box thay vì bật popup."""
        start_count, goal_count = self._count_markers(maze)
        if start_count == 1 and goal_count == 1:
            return True

        problems = []
        if start_count != 1:
            problems.append(f"  Start: {start_count} (requirement: 1)")
        if goal_count != 1:
            problems.append(f"  Goal: {goal_count} (requirement: 1)")

        # Tạo chuỗi thông báo gọn gàng để vừa khít bề ngang info_box
        error_msg = f"Maze is invalid:\n" + "\n".join(problems)
        
        self._update_info(warning_msg=error_msg)
        return False

    # --------------------------------------------------------- ACTIONS ---
    def _on_generate(self):
        if self._animating:
            return
        try:
            n = int(self.n_var.get())
            if not (2 <= n <= MAX_N):
                raise ValueError
        except ValueError:
            messagebox.showerror(
                "Invalid n", f"n phải là số nguyên trong khoảng 2 - {MAX_N}"
            )
            return

        self.n = n
        self.grid_dim = 2 * n + 1
        self.maze = np.zeros((self.grid_dim, self.grid_dim), dtype=int)

        # Điểm carve-seed kỹ thuật cho thuật toán — KHÔNG phải marker Start
        # hiển thị. Người dùng tự đặt Start/Goal sau khi maze sinh xong.
        seed = (1, 1)
        algo_fn = ALGORITHMS[self.algo_name.get()]
        t0 = time.perf_counter()
        frames = algo_fn(self.maze, seed)
        self._gen_time = time.perf_counter() - t0

        self._animate_frames(frames)

    def _animate_frames(self, frames, delay_ms: int = 12):
        self._animating = True
        state = {"i": 0}

        def step():
            if state["i"] >= len(frames):
                self._animating = False
                self.maze = frames[-1]
                self._redraw()
                self._update_info()
                return
            self.maze = frames[state["i"]]
            self._redraw()
            state["i"] += 1
            self._anim_job = self.root.after(delay_ms, step)

        step()

    def _on_erase_maze(self):
        """Xóa tường/đường đi bên trong (trừ viền), nhưng vẫn giữ lại
        marker Start/Goal hiện có (loại trừ theo giá trị ô, không phải
        avoid_position)."""
        if self._animating:
            return
        interior = np.ones_like(self.maze, dtype=bool)
        interior[0, :] = False
        interior[-1, :] = False
        interior[:, 0] = False
        interior[:, -1] = False

        keep_marker = (self.maze == CELL_START) | (self.maze == CELL_GOAL)
        clear_mask = interior & ~keep_marker
        self.maze[clear_mask] = CELL_PATH

        self.maze[0, :] = CELL_WALL
        self.maze[-1, :] = CELL_WALL
        self.maze[:, 0] = CELL_WALL
        self.maze[:, -1] = CELL_WALL

        self._gen_time = None
        self._redraw()
        self._update_info()

    def _on_cancel(self):
        if self._animating and self._anim_job is not None:
            self.root.after_cancel(self._anim_job)
        self._animating = False
        self.maze = np.zeros((self.grid_dim, self.grid_dim), dtype=int)
        self._gen_time = None
        self._redraw()
        self._update_info()

    def _on_save(self):
        if not self._validate_markers(self.maze, "lưu maze"):
            return

        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON maze", "*.json")],
            title="Save maze",
        )
        if not path:
            return
        data = {
            "n": self.n,
            "grid_dim": self.grid_dim,
            "maze": self.maze.tolist(),
            "algorithm": self.algo_name.get(),
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        messagebox.showinfo("Saved", f"Maze đã được lưu vào:\n{path}")

    def _on_load(self):
        path = filedialog.askopenfilename(
            filetypes=[("JSON maze", "*.json")], title="Load maze"
        )
        if not path:
            return
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        loaded_maze = np.array(data["maze"], dtype=int)
        if not self._validate_markers(loaded_maze, "load maze này"):
            return  # giữ nguyên trạng thái hiện tại, không áp dụng file lỗi

        self.n = data["n"]
        self.grid_dim = data["grid_dim"]
        self.maze = loaded_maze
        self.n_var.set(str(self.n))
        if data.get("algorithm") in ALGORITHMS:
            self.algo_name.set(data["algorithm"])
        self._gen_time = None
        self._redraw()
        self._update_info()

    # ------------------------------------------------------------ INFO ---
    def _update_info(self, warning_msg: str = None):
        wall_count = int(np.sum(self.maze == CELL_WALL))
        path_count = int(np.sum(self.maze == CELL_PATH))
        start_count, goal_count = self._count_markers(self.maze)
        start_pos = self._marker_position(self.maze, CELL_START)
        goal_pos = self._marker_position(self.maze, CELL_GOAL)

        lines = [
            f"n (so o):       {self.n} x {self.n}",
            f"Grid array:     {self.grid_dim} x {self.grid_dim}",
            f"Algorithm:      {self.algo_name.get()}",
            f"Wall cells:     {wall_count}",
            f"Path cells:     {path_count}",
            f"Start markers:  {start_count}" + (f"  @ {start_pos}" if start_pos else ""),
            f"Goal markers:   {goal_count}" + (f"  @ {goal_pos}" if goal_pos else ""),
        ]
        if self._gen_time is not None:
            lines.append(f"Gen time:       {self._gen_time * 1000:.1f} ms")

        self.info_box.config(state="normal")
        self.info_box.delete("1.0", "end")
        self.info_box.insert("end", "\n".join(lines))
        
        if warning_msg:
            self.info_box.insert("end", "\n\n[WARNING]:\n" + warning_msg, "warning")
            
        self.info_box.config(state="disabled")


def main():
    root = tk.Tk()
    MazeEditorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()