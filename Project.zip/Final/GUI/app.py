import tkinter as tk
from tkinter import messagebox, ttk

from Core.model import MazeModel
from Core.search_result import SearchResult
from Core.types import Position
from Algorithm.maze_solver import MazeSolver
from GUI.maze_editor_app import MazeEditorApp

# =============================================================================
# MazeApp — Tkinter GUI (layout, drawing, animation, metrics)
# =============================================================================
class MazeApp:
    """
    Tkinter application: controls, four maze panels, search trees, metrics, animation.

    Edit maze settings on the left; results appear in the matching labeled panel (BFS, DFS, …).
    """

    MAX_CANVAS_SIZE = 320  # Max pixel width/height per maze canvas before cells shrink.

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Advanced Maze Solver")

        # Current maze problem instance.
        self.model = MazeModel()
        self.last_results: list[SearchResult] = []

        # Form fields bound to the left control panel.
        self.size_var = tk.StringVar(value="10")
        self.start_r_var = tk.StringVar(value="0")
        self.start_c_var = tk.StringVar(value="0")
        self.goal_r_var = tk.StringVar(value="9")
        self.goal_c_var = tk.StringVar(value="9")
        self.obstacle_var = tk.StringVar(value="15")
        self.heuristic_var = tk.StringVar(value="Manhattan")

        # One canvas / tree / history text per algorithm slot.
        self.algorithm_canvases: dict[str, tk.Canvas] = {}
        self.algorithm_trees: dict[str, ttk.Treeview] = {}
        self.algorithm_histories: dict[str, tk.Text] = {}

        # Animation state (after() callback id and per-slot partial results).
        self.animation_job_id: str | None = None
        self.animation_results_by_slot: dict[str, SearchResult] = {}
        self.animation_index = 0
        self.animation_path_index = 0
        self._mousewheel_bound = False

        self.root.geometry("1200x800")
        self.root.minsize(800, 500)
        self._build_layout()
        self.refresh_transition_table()
    
    def open_maze_editor(self) -> None:
        # Tạo cửa sổ phụ Toplevel
        editor_window = tk.Toplevel(self.root)
        
        # Hàm callback nhận dữ liệu khi bấm nút "Apply" bên Editor
        def handle_applied_maze(grid_array):
            # 1. Nạp ma trận vào Model mới
            self.model = MazeModel(grid_array=grid_array)
            
            # 2. Reset và cập nhật lại bảng thông số Transition Function bên trái
            self.refresh_transition_table()
            
            # 3. Xóa các dữ liệu cây tìm kiếm cũ
            self.clear_search_views()
            self.metrics_text.delete("1.0", tk.END)
            self.metrics_text.insert(tk.END, "Successfully apply new maze. Let's run algorithms!\n")
            
            # 4. Kích hoạt vẽ mê cung trắng lên toàn bộ 4 khung thuật toán
            self.draw_all_static_mazes()

        # Khởi tạo EditorApp và truyền callback vào tham số on_apply
        MazeEditorApp(editor_window, on_apply=handle_applied_maze)

    def _build_layout(self) -> None:
        """Create controls, scrollable main area, four algorithm panels, and output panels."""
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

        # --- Scrollable wrapper so the full UI fits on smaller screens ---
        scroll_outer = ttk.Frame(self.root)
        scroll_outer.grid(row=0, column=0, sticky="nsew")
        scroll_outer.columnconfigure(0, weight=1)
        scroll_outer.rowconfigure(0, weight=1)

        self.main_canvas = tk.Canvas(scroll_outer, highlightthickness=0)
        v_scroll = ttk.Scrollbar(scroll_outer, orient="vertical", command=self.main_canvas.yview)
        h_scroll = ttk.Scrollbar(scroll_outer, orient="horizontal", command=self.main_canvas.xview)
        self.main_canvas.grid(row=0, column=0, sticky="nsew")
        v_scroll.grid(row=0, column=1, sticky="ns")
        h_scroll.grid(row=1, column=0, sticky="ew")
        self.main_canvas.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)

        # Inner panel placed inside the canvas (scroll region grows with content).
        panel = ttk.Frame(self.main_canvas, padding=8)
        self.main_canvas_window = self.main_canvas.create_window((0, 0), window=panel, anchor="nw")
        panel.bind("<Configure>", self._on_scroll_region_update)
        self.main_canvas.bind("<Configure>", self._on_main_canvas_resize)
        self._bind_main_scroll(panel)
        self._bind_main_scroll(self.main_canvas)

        # --- Left column: maze parameters, buttons, transition table ---
        controls = ttk.LabelFrame(panel, text="Controls", padding=8)
        controls.grid(row=0, column=0, sticky="nw", padx=(0, 8))

        ttk.Label(controls, text="Heuristic").grid(row=6, column=0, sticky="w", padx=2, pady=2)
        ttk.Combobox(
            controls,
            values=["Manhattan", "Euclidean"],
            textvariable=self.heuristic_var,
            width=12,
            state="readonly",
        ).grid(row=6, column=1, padx=2, pady=2)

        # Step 1: always generate/regenerate the maze after changing parameters.
        ttk.Button(controls, text="Maze Editor", command=self.open_maze_editor).grid(
            row=7, column=0, columnspan=2, sticky="ew", pady=(8, 2)
        )
        # Step 2: run all four at once (per-algorithm Run buttons sit above each maze panel).
        ttk.Button(controls, text="Run + Animate All", command=self.run_all_animated).grid(
            row=8, column=0, columnspan=2, sticky="ew", pady=(8, 2)
        )

        # Transition function δ(state, action) → next_state (sample rows for current maze).
        transition_frame = ttk.LabelFrame(controls, text="Transition Function", padding=4)
        transition_frame.grid(row=9, column=0, columnspan=2, sticky="nsew", pady=(8, 0))
        transition_frame.columnconfigure(0, weight=1)
        transition_frame.rowconfigure(0, weight=1)

        self.transition_text = tk.Text(transition_frame, width=32, height=12, wrap="none")
        self.transition_text.grid(row=0, column=0, sticky="nsew")
        transition_y_scroll = ttk.Scrollbar(transition_frame, orient="vertical", command=self.transition_text.yview)
        transition_y_scroll.grid(row=0, column=1, sticky="ns")
        transition_x_scroll = ttk.Scrollbar(transition_frame, orient="horizontal", command=self.transition_text.xview)
        transition_x_scroll.grid(row=1, column=0, sticky="ew")
        self.transition_text.configure(
            yscrollcommand=transition_y_scroll.set,
            xscrollcommand=transition_x_scroll.set,
        )

        # ĐÃ CHUYỂN VÀO ĐÂY: Đưa phần khung kết quả xuống dưới cột Controls (row=10)
        # Giảm chiều rộng (width) của các ô Text xuống một chút để vừa vặn với chiều ngang cột trái
        bottom_output = ttk.Frame(controls)
        bottom_output.grid(row=10, column=0, columnspan=2, pady=(8, 0), sticky="ew")
        bottom_output.columnconfigure(0, weight=1)

        # Visited order and final path per algorithm (one tab each).
        self.history_notebook = ttk.Notebook(bottom_output)
        self.history_notebook.grid(row=0, column=0, sticky="nsew")
        for name in ["BFS", "DFS", "Greedy Best-First", "A*"]:
            tab = ttk.Frame(self.history_notebook, padding=4)
            tab.columnconfigure(0, weight=1)
            tab.rowconfigure(0, weight=1)
            self.history_notebook.add(tab, text=name)

            history_frame = ttk.Frame(tab)
            history_frame.grid(row=0, column=0, sticky="nsew")
            history_frame.columnconfigure(0, weight=1)
            history_frame.rowconfigure(0, weight=1)

            # Đã thu gọn width từ 106 xuống 32 để khớp chiều rộng của ô Transition phía trên
            history = tk.Text(history_frame, width=32, height=6, wrap="none")
            history.grid(row=0, column=0, sticky="nsew")

            history_y_scroll = ttk.Scrollbar(history_frame, orient="vertical", command=history.yview)
            history_y_scroll.grid(row=0, column=1, sticky="ns")
            history_x_scroll = ttk.Scrollbar(history_frame, orient="horizontal", command=history.xview)
            history_x_scroll.grid(row=1, column=0, sticky="ew")
            history.configure(yscrollcommand=history_y_scroll.set, xscrollcommand=history_x_scroll.set)

            self.algorithm_histories[name] = history

        metrics_frame = ttk.Frame(bottom_output)
        metrics_frame.grid(row=1, column=0, pady=(8, 0), sticky="nsew")
        metrics_frame.columnconfigure(0, weight=1)
        metrics_frame.rowconfigure(0, weight=1)

        # Đã thu gọn width từ 110 xuống 32 để đồng bộ form giao diện cột trái
        self.metrics_text = tk.Text(metrics_frame, width=32, height=45, wrap="word")
        self.metrics_text.grid(row=0, column=0, sticky="nsew")
        metrics_y_scroll = ttk.Scrollbar(metrics_frame, orient="vertical", command=self.metrics_text.yview)
        metrics_y_scroll.grid(row=0, column=1, sticky="ns")
        self.metrics_text.configure(yscrollcommand=metrics_y_scroll.set)

        # --- Right side: 2×2 maze panels ---
        visual = ttk.Frame(panel)
        visual.grid(row=0, column=1, sticky="nsew")
        panel.columnconfigure(1, weight=1)

        maze_wrap = ttk.Frame(visual)
        maze_wrap.grid(row=0, column=0, sticky="nsew")
        visual.columnconfigure(0, weight=1)
        maze_wrap.columnconfigure(0, weight=1)
        maze_wrap.columnconfigure(1, weight=1)
        maze_wrap.rowconfigure(0, weight=1)
        maze_wrap.rowconfigure(1, weight=1)

        # Grid positions for the four algorithm comparison panels.
        algorithm_slots = [
            ("BFS", 0, 0),
            ("DFS", 0, 1),
            ("Greedy Best-First", 1, 0),
            ("A*", 1, 1),
        ]
        run_labels = {
            "BFS": "Run BFS",
            "DFS": "Run DFS",
            "Greedy Best-First": "Run Greedy Best-First",
            "A*": "Run A*",
        }
        for name, row, col in algorithm_slots:
            frame = ttk.LabelFrame(maze_wrap, text=name, padding=6)
            frame.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")
            frame.columnconfigure(0, weight=1)

            # Run button directly above this panel's maze canvas.
            ttk.Button(
                frame,
                text=run_labels[name],
                command=lambda n=name: self.run_algorithm(n),
            ).grid(row=0, column=0, sticky="ew", pady=(0, 6))

            # Maze drawing area for this algorithm.
            canvas = tk.Canvas(frame, width=self.MAX_CANVAS_SIZE, height=self.MAX_CANVAS_SIZE, bg="white")
            canvas.grid(row=1, column=0, sticky="n")

            # Search tree (parent → child edges) grows during animation.
            tree_frame = ttk.Frame(frame)
            tree_frame.grid(row=2, column=0, pady=(6, 0), sticky="nsew")
            tree_frame.columnconfigure(0, weight=1)
            tree_frame.rowconfigure(0, weight=1)

            tree = ttk.Treeview(tree_frame, columns=("state",), show="tree headings", height=6)
            tree.heading("#0", text="Search Tree")
            tree.heading("state", text="State")
            tree.column("#0", width=120)
            tree.column("state", width=90, anchor="center")
            tree.grid(row=0, column=0, sticky="nsew")

            tree_y_scroll = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
            tree_y_scroll.grid(row=0, column=1, sticky="ns")
            tree.configure(yscrollcommand=tree_y_scroll.set)

            self.algorithm_canvases[name] = canvas
            self.algorithm_trees[name] = tree

    # -------------------------------------------------------------------------
    # Scrolling helpers
    # -------------------------------------------------------------------------
    def _on_scroll_region_update(self, _event: tk.Event | None = None) -> None:
        """Resize scrollable area when inner content grows."""
        self.main_canvas.configure(scrollregion=self.main_canvas.bbox("all"))

    def _on_main_canvas_resize(self, event: tk.Event) -> None:
        """Keep inner panel as wide as the canvas so horizontal scroll is rarely needed."""
        self.main_canvas.itemconfig(self.main_canvas_window, width=event.width)

    def _bind_main_scroll(self, widget: tk.Misc) -> None:
        """Enable mouse-wheel scrolling on the main canvas when pointer enters widget."""
        widget.bind("<Enter>", self._enable_main_mousewheel)
        widget.bind("<Leave>", self._disable_main_mousewheel)

    def _enable_main_mousewheel(self, _event: tk.Event | None = None) -> None:
        if self._mousewheel_bound:
            return
        self.root.bind_all("<MouseWheel>", self._on_main_mousewheel)
        self.root.bind_all("<Button-4>", self._on_main_mousewheel_linux)
        self.root.bind_all("<Button-5>", self._on_main_mousewheel_linux)
        self._mousewheel_bound = True

    def _disable_main_mousewheel(self, _event: tk.Event | None = None) -> None:
        if not self._mousewheel_bound:
            return
        self.root.unbind_all("<MouseWheel>")
        self.root.unbind_all("<Button-4>")
        self.root.unbind_all("<Button-5>")
        self._mousewheel_bound = False

    def _should_scroll_main_canvas(self, event: tk.Event) -> bool:
        """Do not steal wheel events from nested Treeview/Text widgets."""
        widget = self.root.winfo_containing(event.x_root, event.y_root)
        while widget is not None:
            if isinstance(widget, (ttk.Treeview, tk.Text)):
                return False
            widget = widget.master  # type: ignore[assignment]
        return True

    def _on_main_mousewheel(self, event: tk.Event) -> None:
        if not self._should_scroll_main_canvas(event):
            return
        self.main_canvas.yview_scroll(int(-event.delta / 120), "units")

    def _on_main_mousewheel_linux(self, event: tk.Event) -> None:
        if not self._should_scroll_main_canvas(event):
            return
        if event.num == 4:
            self.main_canvas.yview_scroll(-1, "units")
        elif event.num == 5:
            self.main_canvas.yview_scroll(1, "units")

    # -------------------------------------------------------------------------
    # Maze parameters and algorithm execution
    # -------------------------------------------------------------------------
    def parse_params(self) -> tuple[int, Position, Position, int]:
        """Read and validate control-panel fields; raises ValueError if invalid."""
        size = int(self.size_var.get())
        sr = int(self.start_r_var.get())
        sc = int(self.start_c_var.get())
        gr = int(self.goal_r_var.get())
        gc = int(self.goal_c_var.get())
        obstacles = int(self.obstacle_var.get())
        if size < 4:
            raise ValueError("Maze size must be at least 4.")
        if not (0 <= sr < size and 0 <= sc < size and 0 <= gr < size and 0 <= gc < size):
            raise ValueError("Start and goal must be inside the maze.")
        if (sr, sc) == (gr, gc):
            raise ValueError("Start and goal must be different.")
        max_obstacles = size * size - 2
        if not (0 <= obstacles <= max_obstacles):
            raise ValueError(f"Obstacles must be between 0 and {max_obstacles}.")
        return size, (sr, sc), (gr, gc), obstacles

    def apply_parameters(self) -> None:
        """Build a new MazeModel from the form and reset all displays."""
        self.stop_animation()
        try:
            size, start, goal, obstacles = self.parse_params()
        except ValueError as err:
            messagebox.showerror("Invalid parameters", str(err))
            return

        self.model = MazeModel()
        self.last_results.clear()
        self.refresh_transition_table()
        self.metrics_text.delete("1.0", tk.END)
        self.metrics_text.insert(tk.END, "Maze regenerated. Run an algorithm.\n")
        self.clear_search_views()

    def solve_algorithm(self, algo: str) -> SearchResult:
        """Dispatch to the correct MazeSolver method (uses heuristic for Greedy and A*)."""
        heuristic = self.heuristic_var.get()
        if algo == "BFS":
            return MazeSolver.bfs(self.model)
        if algo == "DFS":
            return MazeSolver.dfs(self.model)
        if algo == "Greedy Best-First":
            return MazeSolver.greedy_best_first(self.model, heuristic)
        return MazeSolver.a_star(self.model, heuristic)

    def run_algorithm(self, algo: str) -> None:
        """Run one algorithm with maze + search-tree animation in its panel."""
        result = self.solve_algorithm(algo)
        self.start_animation({algo: result}, [result])

    def run_all_animated(self) -> None:
        """Run BFS, DFS, Greedy, and A* together; all four panels animate in parallel."""
        results = [
            self.solve_algorithm("BFS"),
            self.solve_algorithm("DFS"),
            self.solve_algorithm("Greedy Best-First"),
            self.solve_algorithm("A*"),
        ]
        self.start_animation(
            {
                "BFS": results[0],
                "DFS": results[1],
                "Greedy Best-First": results[2],
                "A*": results[3],
            },
            results,
        )

    # -------------------------------------------------------------------------
    # Animation (two phases: expand visited, then reveal path)
    # -------------------------------------------------------------------------
    def start_animation(
        self,
        results_by_slot: dict[str, SearchResult],
        last_results: list[SearchResult],
    ) -> None:
        """Begin animated playback for one or all algorithm panels."""
        self.stop_animation()
        self.last_results = last_results
        self.animation_results_by_slot = results_by_slot
        self.animation_index = 0
        self.animation_path_index = 0
        self.clear_search_trees()
        self.render_metrics(last_results)
        self.render_move_histories(results_by_slot)
        self._animate_step()

    def stop_animation(self) -> None:
        """Cancel any pending after() animation callback."""
        if self.animation_job_id is not None:
            self.root.after_cancel(self.animation_job_id)
            self.animation_job_id = None

    def _animate_step(self) -> None:
        """One animation tick: expand visited cells, then reveal the path, then finish."""
        if not self.animation_results_by_slot:
            return

        max_visited = max(len(res.visited_order) for res in self.animation_results_by_slot.values())
        max_path = max(len(res.path) for res in self.animation_results_by_slot.values())

        # Phase 1: show search expansion (light blue cells + growing tree).
        if self.animation_index < max_visited:
            visited_limit = self.animation_index + 1
            self.draw_animated_mazes(visited_limit, 0)
            self.render_animated_search_trees(visited_limit)
            self.animation_index += 1
            self.animation_job_id = self.root.after(30, self._animate_step)
            return

        # Phase 2: highlight solution path step by step (yellow cells).
        if self.animation_path_index < max_path:
            self.draw_animated_mazes(max_visited, self.animation_path_index + 1)
            self.animation_path_index += 1
            self.animation_job_id = self.root.after(60, self._animate_step)
            return

        # Phase 3: final static frame with full trees.
        self.render_search_trees(self.animation_results_by_slot)
        self.animation_job_id = None

    def draw_animated_mazes(self, visited_limit: int, path_limit: int) -> None:
        """Redraw all panels using only the first N visited cells and path prefix."""
        for slot, canvas in self.algorithm_canvases.items():
            result = self.animation_results_by_slot.get(slot)
            if result is None:
                # SỬA TẠI ĐÂY: Truyền result=None
                self.draw_single_maze(canvas, result=None)
                continue
            partial_visited = set(result.visited_order[:visited_limit])
            partial_path = set(result.path[:path_limit])
            # SỬA TẠI ĐÂY: Đồng bộ tham số truyền vào
            self.draw_single_maze(canvas, result, partial_visited, partial_path)
    
    def draw_all_static_mazes(self) -> None:
        """Vẽ trạng thái tĩnh ban đầu (chỉ gồm đường đi, tường, start, goal) lên cả 4 khung canvas."""
        for slot, canvas in self.algorithm_canvases.items():
            self.draw_single_maze(canvas, result=None)

    def draw_single_maze(
        self, 
        canvas: tk.Canvas, 
        result: SearchResult | None = None, 
        partial_visited: set[Position] | None = None, 
        partial_path: set[Position] | None = None
    ) -> None:
        """
        Hàm cốt lõi để render đồ họa mê cung lên một ô Canvas cụ thể.
        Hỗ trợ vẽ cả mê cung tĩnh lẫn các ô màu động lúc đang chạy animation.
        """
        canvas.delete("all")
        m = self.model
        if m.rows == 0 or m.cols == 0:
            return

        # Tính toán kích thước ô (pixel) tự động vừa vặn với khung canvas 320x320
        cell_w = self.MAX_CANVAS_SIZE / m.cols
        cell_h = self.MAX_CANVAS_SIZE / m.rows

        # Định nghĩa bảng màu đồng bộ với MazeEditorApp
        COLOR_WALL = "#222222"       # Đen
        COLOR_PATH = "#ffffff"       # Trắng
        COLOR_START = "#2ecc71"      # Xanh lá
        COLOR_GOAL = "#e74c3c"       # Đỏ
        COLOR_VISITED = "#a8dadc"    # Xanh dương nhạt (Trạng thái đã duyệt)
        COLOR_SOLUTION = "#ffcd03"   # Vàng (Đường đi tìm thấy)

        # Quét qua ma trận để vẽ từng ô vuông
        for r in range(m.rows):
            for c in range(m.cols):
                pos = (r, c)
                
                # 1. Xác định màu sắc mặc định dựa trên giá trị ô trong model.grid
                val = m.grid[r][c]
                if val == 0:    # CELL_WALL
                    color = COLOR_WALL
                elif val == 2:  # CELL_START
                    color = COLOR_START
                elif val == 3:  # CELL_GOAL
                    color = COLOR_GOAL
                else:
                    color = COLOR_PATH

                # 2. Nếu đang chạy animation, ghi đè màu sắc của các ô được duyệt/ô thuộc đường đi
                if color == COLOR_PATH:
                    if partial_path and pos in partial_path:
                        color = COLOR_SOLUTION
                    elif partial_visited and pos in partial_visited:
                        color = COLOR_VISITED

                # Tính toán tọa độ pixel trên canvas
                x0 = c * cell_w
                y0 = r * cell_h
                x1 = x0 + cell_w
                y1 = y0 + cell_h

                # Tiến hành vẽ ô vuông lên màn hình
                canvas.create_rectangle(
                    x0, y0, x1, y1,
                    fill=color,
                    outline="#dddddd" if val != 0 else COLOR_WALL
                )

    # -------------------------------------------------------------------------
    # Search trees, move history, metrics, transition table
    # -------------------------------------------------------------------------
    def clear_search_trees(self) -> None:
        for tree in self.algorithm_trees.values():
            tree.delete(*tree.get_children())

    def clear_move_histories(self) -> None:
        for history in self.algorithm_histories.values():
            history.delete("1.0", tk.END)

    def clear_search_views(self) -> None:
        """Reset trees and history tabs (e.g. after generating a new maze)."""
        self.clear_search_trees()
        self.clear_move_histories()

    def render_search_views(self, results_by_slot: dict[str, SearchResult]) -> None:
        self.render_search_trees(results_by_slot)
        self.render_move_histories(results_by_slot)

    def render_search_trees(self, results_by_slot: dict[str, SearchResult]) -> None:
        self.clear_search_trees()
        for name, result in results_by_slot.items():
            self.draw_search_tree(name, result)

    def render_move_histories(self, results_by_slot: dict[str, SearchResult]) -> None:
        self.clear_move_histories()
        for name, result in results_by_slot.items():
            self.draw_move_history(name, result)

    def render_animated_search_trees(self, visited_limit: int) -> None:
        """Show only tree edges discovered up to the current animation frame."""
        self.clear_search_trees()
        for name, result in self.animation_results_by_slot.items():
            visited_so_far = set(result.visited_order[:visited_limit])
            partial_edges = [
                (parent, child) for parent, child in result.edges if child in visited_so_far
            ]
            self.draw_search_tree(name, result, partial_edges)

    def draw_search_tree(
        self,
        algorithm_name: str,
        result: SearchResult,
        edges: list[tuple[Position, Position]] | None = None,
    ) -> None:
        tree = self.algorithm_trees.get(algorithm_name)
        if tree is None:
            return
            
        tree_edges = result.edges if edges is None else edges
        
        root_coords = self.model.start
        root_label = f"Root Node {root_coords}"
        root_id = tree.insert("", "end", text=root_label, values=(f"Start {root_coords}",))
        
        node_refs: dict[Position, str] = {root_coords: root_id}

        def get_action_direction(p: Position, c: Position) -> str:
            dr, dc = c[0] - p[0], c[1] - p[1]
            if dr == -1 and dc == 0: return "↑ Up"
            if dr == 1 and dc == 0: return "↓ Down"
            if dr == 0 and dc == -1: return "← Left"
            if dr == 0 and dc == 1: return "→ Right"
            return "Move"

        for parent, child in tree_edges:
            parent_id = node_refs.get(parent, root_id)
            
            direction = get_action_direction(parent, child)
            node_label = f"Node {child}"
            child_id = tree.insert(
                parent_id, 
                "end", 
                text=node_label, 
                values=(direction,)
            )
            
            node_refs[child] = child_id

    def draw_move_history(self, algorithm_name: str, result: SearchResult) -> None:
        """Fill the history tab with visited order, path, and directional moves."""
        history = self.algorithm_histories.get(algorithm_name)
        if history is None:
            return
        history.insert(tk.END, f"Algorithm: {result.algorithm}\n")
        history.insert(tk.END, f"Visited order: {result.visited_order[:60]}")
        if len(result.visited_order) > 60:
            history.insert(tk.END, " ...")
        history.insert(tk.END, "\n")
        if result.found:
            history.insert(tk.END, f"Path ({len(result.path) - 1} steps): {result.path}\n")
            moves = self.positions_to_moves(result.path)
            history.insert(tk.END, f"Moves: {moves}\n")
        else:
            history.insert(tk.END, "Path: not found\n")

    @staticmethod
    def positions_to_moves(path: list[Position]) -> list[str]:
        """Convert consecutive grid positions into up/down/left/right action names."""
        moves: list[str] = []
        for i in range(1, len(path)):
            pr, pc = path[i - 1]
            cr, cc = path[i]
            dr, dc = cr - pr, cc - pc
            if dr == -1 and dc == 0:
                moves.append("up")
            elif dr == 1 and dc == 0:
                moves.append("down")
            elif dr == 0 and dc == -1:
                moves.append("left")
            elif dr == 0 and dc == 1:
                moves.append("right")
        return moves

    def render_metrics(self, results: list[SearchResult]) -> None:
        """Write completeness, optimality, runtime, and complexity for each run."""
        self.metrics_text.delete("1.0", tk.END)
        for res in results:
            self.metrics_text.insert(tk.END, f"Algorithm: {res.algorithm}\n")
            self.metrics_text.insert(tk.END, f"Found path: {'Yes' if res.found else 'No'}\n")
            self.metrics_text.insert(tk.END, f"Path length: {max(0, len(res.path) - 1)}\n")
            self.metrics_text.insert(tk.END, f"Nodes expanded: {res.nodes_expanded}\n")
            self.metrics_text.insert(tk.END, f"Max frontier size: {res.max_frontier}\n")
            self.metrics_text.insert(tk.END, f"Runtime: {res.elapsed_ms:.3f} ms\n")
            self.metrics_text.insert(tk.END, f"Completeness: {res.completeness}\n")
            self.metrics_text.insert(tk.END, f"Optimality: {res.optimality}\n")
            self.metrics_text.insert(tk.END, f"Time complexity: {res.time_complexity}\n")
            self.metrics_text.insert(tk.END, f"Space complexity: {res.space_complexity}\n")
            self.metrics_text.insert(tk.END, "-" * 62 + "\n")

    def refresh_transition_table(self) -> None:
        """Refresh left-panel sample of δ(state, action) for the current maze."""
        m = self.model
        self.transition_text.delete("1.0", tk.END)
        
        # SỬA TẠI ĐÂY: Thay thế m.size bằng m.rows và m.cols để lấy kích thước thực tế
        self.transition_text.insert(
            tk.END,
            f"Maze {m.rows}×{m.cols}  |  start {m.start}  |  goal {m.goal}  |  {len(m.obstacles)} obstacles\n",
        )
        self.transition_text.insert(tk.END, "delta(state, action) -> next state\n\n")
        self.transition_text.insert(tk.END, "Current State | Action | Next State\n")
        self.transition_text.insert(tk.END, "-" * 46 + "\n")
        for current, action, nxt in m.transition_table_sample(rows=16):
            self.transition_text.insert(tk.END, f"{current!s:<14} | {action:<5} | {nxt}\n")
        # Scroll to top so a regenerated maze is obvious (view may have been scrolled down).
        self.transition_text.see("1.0")
        self.transition_text.xview_moveto(0.0)
