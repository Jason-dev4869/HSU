from Core.types import Position
"""Graph search algorithms. Each method returns a SearchResult for the GUI."""
@staticmethod
def reconstruct_path(parent: dict[Position, Position | None], goal: Position) -> list[Position]:
    """Walk parent pointers from goal back to start."""
    if goal not in parent:
        return []
    path = [goal]
    cur = goal
    while parent[cur] is not None:
        cur = parent[cur]  # type: ignore[index]
        path.append(cur)
    path.reverse()
    return path